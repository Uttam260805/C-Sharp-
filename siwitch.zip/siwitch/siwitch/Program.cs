﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace siwitch
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter 1 for yellow \n enter 2 for cyan \n enter 3 for red \n enter 4 for green\n enter 5 for blue \n enter 6 for magenta");
            int n = Convert.ToInt32(Console.ReadLine());
            switch (n)
            {
                case 1: Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine("yellow");
                    break;

                case 2: Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("cyan");
                    break;

                case 3: Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("red");
                    break;

                case 4: Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("green");
                    break;

                case 5: Console.ForegroundColor = ConsoleColor.Blue;
                    Console.WriteLine("blue");
                    break;

                case 6: Console.ForegroundColor = ConsoleColor.Magenta;
                    Console.WriteLine("magenta");
                    break;
           }
            Console.Read();

        }
    }
}
