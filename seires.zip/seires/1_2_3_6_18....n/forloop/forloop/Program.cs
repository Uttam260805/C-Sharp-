﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace forloop
{
    class Program
    {
        static void Main(string[] args)
        {

            // 1    2   3   6   18  108 .....   n;
            Console.WriteLine("enter any value:");
            int n = Convert.ToInt32(Console.ReadLine());
            int i, o = 2, p = 3;
            for (i = 1; i <= n; i++)
            {
                if (i <= 3)
                {
                    Console.Write(i + " ");

                }
                else
                {
                    i = o * p;
                    if (i >= n)
                    {
                        break;
                    }
                    Console.Write(i + " ");
                    o = p;
                    p = i;
                }
            }
            Console.Read();
        }
    }
}
