﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace forloop
{
    class Program
    {
        static void Main(string[] args)
        {
            /* 1
             * 2    3
             * 6    18  108... n*/
            Console.WriteLine("enter any value: ");
            int n = Convert.ToInt32(Console.ReadLine());
            int i, op = 2, nm = 3, x = 1;
            for (i = 1; i <= n; i++)
            {
                int j;
                for (j = 1; j <= i; j++)
                {
                    if (x <= 3)
                    {
                        Console.Write(x + " ");
                    }
                    else
                    {
                        x = op * nm;
                        if (x > n)
                        {
                            break;
                        }
                        Console.Write(x + " ");
                        op = nm;
                        nm = x;
                    }
                    x++;
                }
                if (x > n)
                {
                    break;
                }
                Console.WriteLine();
            }
            Console.Read();
        }
    }
}
