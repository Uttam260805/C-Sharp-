﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace whileloop
{
    class Program
    {
        static void Main(string[] args)
        {
            /* 1
             * 2    3
             * 6    18  108... n*/
            Console.WriteLine("enter any value: ");
            int n = Convert.ToInt32(Console.ReadLine());
            int i = 1, op = 2, nm = 3, x = 1;
            while (i <= n)
            {
                int j = 1;
                while (j <= i)
                {
                    if (x <= 3)
                    {
                        Console.Write(x + " ");
                    }
                    else
                    {
                        x = op * nm;
                        if (x > n)
                        {
                            break;
                        }
                        Console.Write(x + " ");
                        op = nm;
                        nm = x;
                    }
                    x++;
                    j++;
                }
                i++;
                if (x > n)
                {
                    break;
                }
                Console.WriteLine();
            }
            Console.Read();
        }
    }
}
