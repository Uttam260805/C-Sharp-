﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace if_condition
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.BackgroundColor = ConsoleColor.DarkCyan;
            Console.Clear();
            Console.Write("enter your age: ");
            int a = Convert.ToInt32(Console.ReadLine());
            if (a <= 0)
            {
                Console.WriteLine("not exits");
            }
            else
            {
                if (a < 18)
                {
                    Console.WriteLine("you are teenage");
                }
                else if (a > 18 && a < 60)
                {
                    Console.WriteLine("you are young");
                }
                else if (a > 60 && a < 120)
                {
                    Console.WriteLine("you are senior citizen");
                }
                else
                {
                    Console.WriteLine("out of your age");
                }
            }
            Console.Read();
        }
    }
}
