﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _3d_array
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            int[, ,] a = new int[2, 2, 2];
            a[0, 0, 0] = 1;
            a[0, 0, 1] = 2;
            a[0, 1, 0] = 3;
            a[0, 1, 1] = 4;
            a[1, 0, 0] = 5;
            a[1, 0, 1] = 6;
            a[1, 1, 0] = 7;
            a[1, 1, 1] = 8;
            foreach (int i in a)
            {
                Console.Write(" " + i);
            }
            Console.Read();
        }
    }
}
