﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace if_condition
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write("enter your age: ");
            int a = Convert.ToInt32(Console.ReadLine());
            if (a > 0)
            {
                if (a < 18)
                {
                    Console.WriteLine("child");
                }
                else if (a >= 18 && a < 60)
                {
                    Console.WriteLine("young");
                }
                else if (a >=60 && a < 135 )
                {
                    Console.WriteLine("sinior");
                }
                else
                {
                    Console.WriteLine("enter valid no of your age");
                }
            }
            else
            {
                Console.WriteLine("enter valid no of your age");
            }
            Console.Read();
        }
    }
}
