﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {

            // 1    2   3   6   18  108 .....   n;
            Console.WriteLine("enter any value:");
            int n = Convert.ToInt32(Console.ReadLine());
            int i = 1, o = 2, p = 3;
            while (i <= n)
            {
                if (i <= 3)
                {
                    Console.Write(i + " ");
                    i++;
                }
                else
                {
                    i = o * p;
                    if (i >= n)
                    {
                        break;
                    }
                    Console.Write(i + " ");
                    o = p;
                    p = i;
                }
            }
            Console.Read();
        
        }
    }
}
